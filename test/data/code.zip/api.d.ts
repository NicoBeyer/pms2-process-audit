export declare class Api {
    call(event: any): Promise<{}>;
    /**
     * https://api.beyer-soehne.de/customerdb/orders?start={date.add(-62).format()}&fields=id,total_price,created_at,cancelled_at,line_items.variant_id,line_items.product_id,line_items.quantity,line_items.title,line_items.variant_title,line_items.created_at,line_items.order_id,customer.id,customer.orders_count,tags,financial_status
     *
     * @param event
     */
    getOrders(event: any): Promise<{
        orders: any;
        timestamp: Date;
    }>;
    getRevenue(event: any): Promise<any>;
    getLeakingBucket(event: any): Promise<any[]>;
}

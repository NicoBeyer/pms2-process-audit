import { Config as ConfigLoader } from "@nbeyer/bs-config-loader";
export declare class PrivateConfig extends ConfigLoader {
    mongodb: string;
    mongoUser: string;
    mongoPassword: string;
    constructor();
    connectDb(db?: string, user?: string, pwd?: string): Promise<void>;
    isConnected(): boolean;
    cleanUp(): Promise<void>;
}
export declare let Config: PrivateConfig;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bs_config_loader_1 = require("@nbeyer/bs-config-loader");
const bs_customer_db_model_1 = require("@nbeyer/bs-customer-db-model");
const DEFAULT_DB = "mongodb://localhost:27017/customerDbTest";
class PrivateConfig extends bs_config_loader_1.Config {
    constructor() {
        super();
    }
    async connectDb(db, user, pwd) {
        const database = db || this.mongodb || DEFAULT_DB;
        const dbUser = user || this.mongoUser || undefined;
        const dbPwd = pwd || this.mongoPassword || undefined;
        await bs_customer_db_model_1.DB.connect(database, dbUser, dbPwd, true);
    }
    isConnected() {
        return bs_customer_db_model_1.DB.isConnected();
    }
    async cleanUp() {
        if (bs_customer_db_model_1.DB.isConnected()) {
            await bs_customer_db_model_1.DB.disconnect();
        }
    }
}
exports.PrivateConfig = PrivateConfig;
exports.Config = new PrivateConfig();

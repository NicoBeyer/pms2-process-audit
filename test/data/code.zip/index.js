"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const pms_serviceinstance_1 = require("@nbeyer/pms-serviceinstance");
const api_1 = require("./api");
const Customer_1 = require("./Model/Customer");
const UpdateMessage_1 = require("./Messages/Input/UpdateMessage");
const UpdateMetaMessage_1 = require("./Messages/Input/UpdateMetaMessage");
const Order_1 = require("./Model/Order");
class CustomerDbService extends pms_serviceinstance_1.StandaloneServiceInstance {
    static getServiceTitle() {
        return "CustomerDb";
    }
    async consume(msg) {
        const self = this;
        try {
            if (process.env.DEBUG) {
                console.log(JSON.stringify(msg));
            }
            if (!msg.type) {
                // throw new Error("Invalid message. type is missing.");
                msg.type = "UPDATE"; // HACK some messages in Prod don't have type right now. Expect default.
            }
            let events = [];
            // Save message to DB
            switch (msg.type) {
                case UpdateMessage_1.UpdateMessage.TYPE:
                    const message = new UpdateMessage_1.UpdateMessage(msg);
                    events = await message.save();
                    break;
                case UpdateMetaMessage_1.UpdateMetaMessage.TYPE:
                    const messageMeta = new UpdateMetaMessage_1.UpdateMetaMessage(msg);
                    events = await messageMeta.save();
                    break;
                default:
                    throw new Error("Unknown message type: " + msg.type);
            }
            const promises = [];
            for (const event of events) {
                promises.push(this.send(event));
            }
            await Promise.all(promises);
        }
        catch (err) {
            console.log(err);
            throw err;
        }
    }
    async run(event) {
        if (process.env.DEBUG) {
            console.log(event);
        }
        if (event.test === true) {
            const orderCount = await Order_1.Order.count({});
            const customerCount = await Customer_1.Customer.count({});
            const ret = {
                status: "DB connection ok.",
                orderCount,
                customerCount,
            };
            console.log(ret);
            this.callback(null, ret);
        }
        else if (event.api) {
            const api = new api_1.Api();
            const ret = await api.call(event);
            this.callback(null, ret);
        }
    }
    async admin(event) {
        try {
            const ret = {
                orderCount: await Order_1.Order.count({}),
                customerCount: await Customer_1.Customer.count({}),
                orderCount30: await Order_1.Order.count({
                    created_at: { $gte: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30) }
                }),
                amazonOrders30: await Order_1.Order.count({
                    created_at: { $gte: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30) },
                    tags: { $regex: "Amazon" },
                }),
            };
            return ret;
        }
        catch (err) {
            return JSON.stringify(err);
        }
    }
}
exports.CustomerDbService = CustomerDbService;
exports.handler = CustomerDbService.getHandler();

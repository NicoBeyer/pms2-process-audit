"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Customer_1 = require("../../Model/Customer");
const Order_1 = require("../../Model/Order");
/**
 *  UpdateMessage takes messages, validates messages and manipulates database object accordingly.
 *
 *  # Identify which objects to manipulate
 *  An object in the database (e.g. CanonicalOrder or CanonicalCustomer) are identified by the manifestation that
 *  is transmitted with the message.
 *  If no manifestation is transmitted the message is rejected.
 *  If an object has multiple manifestations, it must be clear which manifestation actually creates new objects.
 *  Secondary manifestations (e.g. Amazon Orders that will also be represented as wooCommerce Orders), must be added
 *  with a UPDATE_MANIFESTATION query.
 *
 *  # Updating object fields
 *  The update only sets the fields present in the message. Other fields will remain untouched in the database.
 *  A field in the database therfore can't be deleted. Only set to Null.
 *  The manifestation in the database will be replaced by the new manifestation.
 *
 */
class UpdateMetaMessage {
    constructor(message) {
        if (!message
            || !message.type
            || message.type !== UpdateMetaMessage.TYPE) {
            throw new Error("Ivalid Message: " + JSON.stringify(message));
        }
        if (!message.identifier) {
            throw new Error("Identifier not defined.");
        }
        if (!message.update) {
            throw new Error("No update instructions found. set or append must be defined.");
        }
        Object.assign(this, message);
    }
    async save() {
        let event;
        if (process.env.DEBUG) {
            console.log("Saving meta data with message:");
            console.log(JSON.stringify(this));
        }
        if (this.identifier.order) {
            event = await Order_1.Order.updateMeta(this.identifier.order, this.update, this.upsert);
            if (!event) {
                throw new Error("order with id " + this.identifier.order.id + " from "
                    + this.identifier.order.source_name + " was not found in db.");
            }
        }
        else if (this.identifier.customer) {
            event = await Customer_1.Customer.updateMeta(this.identifier.customer, this.update, this.upsert);
            if (!event) {
                throw new Error("Customer with id " + JSON.stringify(this.identifier) + " was not found in db.");
            }
        }
        return [event];
    }
}
UpdateMetaMessage.TYPE = "UPDATE_META";
exports.UpdateMetaMessage = UpdateMetaMessage;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bs_customer_db_model_1 = require("@nbeyer/bs-customer-db-model");
const pms_serviceinstance_1 = require("@nbeyer/pms-serviceinstance");
const Customer_1 = require("../../Model/Customer");
const Order_1 = require("../../Model/Order");
const log = pms_serviceinstance_1.Logger.get("UpdateMessage");
/**
 *  UpdateMessage takes messages, validates messages and manipulates database object accordingly.
 *
 *  # Identify which objects to manipulate
 *  An object in the database (e.g. CanonicalOrder or CanonicalCustomer) are identified by the manifestation that
 *  is transmitted with the message.
 *  If no manifestation is transmitted the message is rejected.
 *  If an object has multiple manifestations, it must be clear which manifestation actually creates new objects.
 *  Secondary manifestations (e.g. Amazon Orders that will also be represented as wooCommerce Orders), must be added
 *  with a UPDATE_MANIFESTATION query.
 *
 *  # Updating object fields
 *  The update only sets the fields present in the message. Other fields will remain untouched in the database.
 *  A field in the database therefore can't be deleted. Only set to Null.
 *  The manifestation in the database will be replaced by the new manifestation.
 *
 */
class UpdateMessage {
    constructor(message) {
        if (!message
            || !message.type
            || message.type !== UpdateMessage.TYPE) {
            throw new Error("Ivalid Message: " + JSON.stringify(message));
        }
        if (!message.manifestation) {
            throw new Error("Manifestation not found.");
        }
        if (message.manifestation instanceof bs_customer_db_model_1.Manifestation) {
            this.manifestation = message.manifestation;
        }
        else {
            this.manifestation = bs_customer_db_model_1.Manifestation.instantiate(message.manifestation);
        }
        if (message.order) {
            this.order = Order_1.Order.instantiate(message.order);
        }
        else if (message.customer) {
            this.customer = Customer_1.Customer.instantiate(message.customer);
        }
        else {
            throw new Error("Invalid message: update object is missing.");
        }
    }
    async save() {
        const db = bs_customer_db_model_1.DB;
        await this.manifestation.save();
        let events;
        if (this.order) {
            events = await this.order.updateDb();
            log.info("Order saved: " + this.order.source_name + "/" + this.order.id);
        }
        else if (this.customer) {
            events = await this.customer.updateDb();
            log.info("Customer saved: " + this.customer.id);
        }
        else {
            throw new Error("No object ready to be saved.");
        }
        return events;
    }
}
UpdateMessage.TYPE = "UPDATE";
exports.UpdateMessage = UpdateMessage;

import { CanonicalCustomer, CanonicalOrder, Manifestation } from "@nbeyer/bs-customer-db-model";
import { ICustomerDbMessage } from "../Output/ICustomerDbMessage";
export declare type UpdateMessageType = "UPDATE";
export interface IUpdateMessage {
    type: UpdateMessageType;
    customer?: CanonicalCustomer;
    order?: CanonicalOrder;
    manifestation: Manifestation;
}
/**
 *  UpdateMessage takes messages, validates messages and manipulates database object accordingly.
 *
 *  # Identify which objects to manipulate
 *  An object in the database (e.g. CanonicalOrder or CanonicalCustomer) are identified by the manifestation that
 *  is transmitted with the message.
 *  If no manifestation is transmitted the message is rejected.
 *  If an object has multiple manifestations, it must be clear which manifestation actually creates new objects.
 *  Secondary manifestations (e.g. Amazon Orders that will also be represented as wooCommerce Orders), must be added
 *  with a UPDATE_MANIFESTATION query.
 *
 *  # Updating object fields
 *  The update only sets the fields present in the message. Other fields will remain untouched in the database.
 *  A field in the database therefore can't be deleted. Only set to Null.
 *  The manifestation in the database will be replaced by the new manifestation.
 *
 */
export declare class UpdateMessage {
    static readonly TYPE = "UPDATE";
    private order;
    private customer;
    private type;
    private manifestation;
    constructor(message: IUpdateMessage);
    save(): Promise<ICustomerDbMessage[]>;
}

import { ICustomerDbOrderMessage } from "./ICustomerDbMessage";
export declare type OrderCreatedMessageType = "ORDER_CREATED";
export interface IOrderCreatedMessage extends ICustomerDbOrderMessage {
    type: OrderCreatedMessageType;
}

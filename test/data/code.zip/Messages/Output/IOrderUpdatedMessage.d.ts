import { ICustomerDbOrderMessage } from "./ICustomerDbMessage";
export declare type OrderUpdatedMessageType = "ORDER_UPDATED";
export interface IOrderUpdatedMessage extends ICustomerDbOrderMessage {
    type: OrderUpdatedMessageType;
    changes: any;
}

import { ICustomerDbCustomerMessage } from "./ICustomerDbMessage";
export declare type CustomerUpdatedMessageType = "CUSTOMER_UPDATED";
export interface ICustomerUpdatedMessage extends ICustomerDbCustomerMessage {
    type: CustomerUpdatedMessageType;
    changes: any;
}

import { ICustomerDbOrderMessage } from "./ICustomerDbMessage";
export declare type OrderClosedMessageType = "ORDER_CLOSED";
export interface IOrderClosedMessage extends ICustomerDbOrderMessage {
    type: OrderClosedMessageType;
}

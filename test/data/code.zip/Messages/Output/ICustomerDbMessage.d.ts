import { CanonicalCustomer, CanonicalOrder } from "@nbeyer/bs-customer-db-model";
import { CustomerUpdatedMessageType } from "./ICustomerUpdatedMessage";
import { OrderCancelledMessageType } from "./IOrderCancelledMessage";
import { IOrderClosedMessage, OrderClosedMessageType } from "./IOrderClosedMessage";
import { IOrderCreatedMessage, OrderCreatedMessageType } from "./IOrderCreatedMessage";
import { IOrderFulfilledMessage, OrderFulfilledMessageType } from "./IOrderFulfilledMessage";
import { IOrderPaidMessage, OrderPaidMessageType } from "./IOrderPaidMessage";
import { IOrderUpdatedMessage, OrderUpdatedMessageType } from "./IOrderUpdatedMessage";
export declare enum OrderEvents {
    ORDER_CREATED = "ORDER_CREATED",
    ORDER_UPDATED = "ORDER_UPDATED",
    ORDER_FULFILLED = "ORDER_FULFILLED",
    ORDER_CANCELLED = "ORDER_CANCELLED",
    ORDER_CLOSED = "ORDER_CLOSED",
    ORDER_PAID = "ORDER_PAID"
}
export declare type CustomerDbMessageType = CustomerUpdatedMessageType | OrderCancelledMessageType | OrderClosedMessageType | OrderCreatedMessageType | OrderFulfilledMessageType | OrderPaidMessageType | OrderUpdatedMessageType;
export declare type OrderEventMessage = ICustomerDbOrderMessage | IOrderClosedMessage | IOrderFulfilledMessage | IOrderPaidMessage | IOrderCreatedMessage | IOrderUpdatedMessage;
export interface ICustomerDbMessage {
    type: CustomerDbMessageType;
}
export interface ICustomerDbOrderMessage extends ICustomerDbMessage {
    order: CanonicalOrder;
}
export interface ICustomerDbCustomerMessage extends ICustomerDbMessage {
    type: CustomerDbMessageType;
    customer: CanonicalCustomer;
}

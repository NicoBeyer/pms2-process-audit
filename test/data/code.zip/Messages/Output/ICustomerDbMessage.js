"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var OrderEvents;
(function (OrderEvents) {
    OrderEvents["ORDER_CREATED"] = "ORDER_CREATED";
    OrderEvents["ORDER_UPDATED"] = "ORDER_UPDATED";
    OrderEvents["ORDER_FULFILLED"] = "ORDER_FULFILLED";
    OrderEvents["ORDER_CANCELLED"] = "ORDER_CANCELLED";
    OrderEvents["ORDER_CLOSED"] = "ORDER_CLOSED";
    OrderEvents["ORDER_PAID"] = "ORDER_PAID";
})(OrderEvents = exports.OrderEvents || (exports.OrderEvents = {}));

import { CanonicalFulfillment, CanonicalLineItem } from "@nbeyer/bs-customer-db-model";
import { ICustomerDbOrderMessage } from "./ICustomerDbMessage";
export declare type OrderFulfilledMessageType = "ORDER_FULFILLED";
export interface IOrderFulfilledMessage extends ICustomerDbOrderMessage {
    type: "ORDER_FULFILLED";
    fulfillment: CanonicalFulfillment;
    line_items: CanonicalLineItem[];
}

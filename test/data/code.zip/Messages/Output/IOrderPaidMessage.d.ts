import { ICustomerDbOrderMessage } from "./ICustomerDbMessage";
export declare type OrderPaidMessageType = "ORDER_PAID";
export interface IOrderPaidMessage extends ICustomerDbOrderMessage {
    type: OrderPaidMessageType;
}

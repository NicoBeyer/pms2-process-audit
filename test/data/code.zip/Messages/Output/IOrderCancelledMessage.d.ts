import { ICustomerDbOrderMessage } from "./ICustomerDbMessage";
export declare type OrderCancelledMessageType = "ORDER_CANCELLED";
export interface IOrderCancelledMessage extends ICustomerDbOrderMessage {
    type: OrderCancelledMessageType;
}

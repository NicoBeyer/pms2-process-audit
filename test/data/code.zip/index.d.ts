import { StandaloneServiceInstance } from "@nbeyer/pms-serviceinstance";
export declare class CustomerDbService extends StandaloneServiceInstance {
    static getServiceTitle(): string;
    consume(msg: any): Promise<void>;
    run(event: any): Promise<void>;
    admin(event: any): Promise<string | {
        orderCount: number;
        customerCount: number;
        orderCount30: number;
        amazonOrders30: number;
    }>;
}
export declare let handler: (event: any, context: any, callback: (err: Error, data: any) => void) => void;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bs_customer_db_model_1 = require("@nbeyer/bs-customer-db-model");
const pms_serviceinstance_1 = require("@nbeyer/pms-serviceinstance");
const project = require("mongo-project");
const diff_1 = require("../lib/diff");
const helper_1 = require("../lib/helper");
const ICustomerDbMessage_1 = require("../Messages/Output/ICustomerDbMessage");
const log = pms_serviceinstance_1.Logger.get("Order");
class Order extends bs_customer_db_model_1.CanonicalOrder {
    static async updateMeta(orderId, query, upsert) {
        const order = await Order.findOneAndLock({
            id: orderId.id,
            source_name: orderId.source_name,
        });
        if (!order && upsert) {
            // TODO implement Upsert
            return null;
        }
        else if (!order) {
            return null;
        }
        order.bs_meta = order.bs_meta || {};
        const original = JSON.parse(JSON.stringify(order.bs_meta));
        await order.update({
            namespace: "bs_meta",
            update: query,
        });
        await order.saveAndUnlock({ bs_meta: 1 });
        if (log.isDebug()) {
            log.debug("Sucessfully saved meta on order: " + order.id);
        }
        return {
            type: "ORDER_UPDATED",
            order,
            changes: { bs_meta: diff_1.objectDiff(original, order.bs_meta) },
        };
    }
    /**
     * @returns {Promise<CanonicalOrder>}: The event that took place on this change.
     */
    async updateDb() {
        // We don't want to overwrite bs_meta.
        const bs_meta = this.bs_meta;
        if (this.bs_meta) {
            log.warn("bs_meta will not be saved on update message.");
            delete this.bs_meta;
        }
        const query = [{
                source_name: this.source_name,
                id: this.id,
            }, {
                $set: this,
            }, {
                upsert: true,
                returnOriginal: true,
            }];
        if (log.isTrace()) {
            log.trace("updating Order with: " + JSON.stringify(query));
        }
        const original = await Order.findOneAndUpdate({
            source_name: this.source_name,
            id: this.id,
        }, {
            $set: this,
        }, {
            upsert: true,
            returnOriginal: true,
        });
        if (log.isTrace()) {
            log.trace("updating Order DONE");
        }
        const events = [];
        // Case no fields updated return no events
        const projection = {
            _id: 0,
            customer: 0,
            private_data: 0,
        };
        const a = project(JSON.parse(JSON.stringify(this)), projection);
        const b = project(JSON.parse(JSON.stringify(original)), projection);
        if (helper_1.leftDeepEqual(a, b)) {
            if (log.isDebug()) {
                log.debug("No change: " + JSON.stringify(this) + JSON.stringify(original));
            }
            return events;
        }
        // Case created
        if (!original) {
            events.push({ type: ICustomerDbMessage_1.OrderEvents.ORDER_CREATED, order: this });
        }
        // Case paid
        if ((!original || original.financial_status !== "paid") && this.financial_status === "paid") {
            events.push({ type: ICustomerDbMessage_1.OrderEvents.ORDER_PAID, order: this });
        }
        // Case fulfilled
        if (this.fulfillments && this.fulfillments.length > 0
            && (!original || !original.fulfillments || this.fulfillments.length > original.fulfillments.length)) {
            const newFulfillments = [];
            const orgFulfillments = (original && original.fulfillments) || [];
            for (const fulfillment of this.fulfillments) {
                let newFulfillment = fulfillment;
                for (const orgFulfillment of orgFulfillments) {
                    if (orgFulfillment.id === newFulfillment.id) {
                        newFulfillment = null;
                        break;
                    }
                }
                if (newFulfillment) {
                    events.push({
                        type: ICustomerDbMessage_1.OrderEvents.ORDER_FULFILLED,
                        fulfillment: newFulfillment,
                        line_items: newFulfillment.line_items,
                        order: this,
                    });
                }
            }
        }
        // Case cancelled
        if ((!original || original.cancelled_at === null) && this.cancelled_at) {
            const event = { type: ICustomerDbMessage_1.OrderEvents.ORDER_CANCELLED, order: this };
            events.push(event);
        }
        else if ((!original || original.closed_at === null) && this.closed_at) {
            // Case cancelled
            events.push({ type: ICustomerDbMessage_1.OrderEvents.ORDER_CLOSED, order: this });
        }
        const changes = diff_1.objectDiff(original, this);
        delete changes._id;
        if (typeof changes.bs_meta === "undefined") {
            delete changes.bs_meta;
        }
        events.push({
            type: ICustomerDbMessage_1.OrderEvents.ORDER_UPDATED,
            order: this,
            changes,
        });
        this.bs_meta = bs_meta;
        if (log.isTrace()) {
            log.trace("updateDb DONE with events: " + JSON.stringify(events));
        }
        return events;
    }
}
exports.Order = Order;

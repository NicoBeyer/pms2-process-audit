"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bs_customer_db_model_1 = require("@nbeyer/bs-customer-db-model");
const pms_serviceinstance_1 = require("@nbeyer/pms-serviceinstance");
const project = require("mongo-project");
const diff_1 = require("../lib/diff");
const helper_1 = require("../lib/helper");
const log = pms_serviceinstance_1.Logger.get("Customer");
class Customer extends bs_customer_db_model_1.CanonicalCustomer {
    static async updateMeta(customerId, query, upsert) {
        const selector = {};
        if (customerId.email_hash) {
            selector.email_hash = customerId.email_hash;
        }
        else if (customerId.id_md5) {
            selector.id_md5 = customerId.id_md5;
        }
        else {
            throw new Error("Invalid CustomerIdentifier");
        }
        let customer = await Customer.findOneAndLock(selector);
        const ret = {
            type: "CUSTOMER_UPDATED",
            customer: null,
            changes: {},
        };
        if (!customer && upsert) {
            if (!customerId.email_hash) {
                throw new Error("email_hash must be definded to upsert customer.");
            }
            customer = new Customer();
            customer.email_hash = customerId.email_hash;
            await customer.save();
            ret.changes = customer;
        }
        else if (!customer) {
            return null;
        }
        customer.bs_meta = customer.bs_meta || {};
        const original = JSON.parse(JSON.stringify(customer.bs_meta));
        await customer.update({
            namespace: "bs_meta",
            update: query,
        });
        await customer.saveAndUnlock({ bs_meta: 1 });
        if (log.isDebug()) {
            log.debug("Sucessfully saved meta on order: " + customer.id);
        }
        ret.changes.bs_meta = diff_1.objectDiff(original, customer.bs_meta);
        ret.customer = customer;
        return ret;
    }
    /**
     * @returns {Promise<CanonicalOrder>}: The event that took place on this change.
     */
    async updateDb() {
        const manifestations_id = this.manifestations_id;
        delete this.manifestations_id;
        // We don't want to overwrite bs_meta.
        const bs_meta = this.bs_meta;
        if (this.bs_meta) {
            log.warn("bs_meta will not be saved on update message.");
            delete this.bs_meta;
        }
        const original = await Customer.findOneAndUpdate({
            email_hash: this.email_hash,
        }, {
            $set: this,
            $addToSet: { manifestations_id: { $each: manifestations_id } },
        }, {
            upsert: true,
            returnOriginal: true,
        });
        const events = [];
        // Case no fields updated return no events
        const projection = {
            _id: 0,
            private_data: 0,
        };
        const a = project(JSON.parse(JSON.stringify(this)), projection);
        const b = project(JSON.parse(JSON.stringify(original)), projection);
        if (helper_1.leftDeepEqual(a, b)) {
            if (log.isDebug()) {
                log.debug("No change: " + JSON.stringify(this) + JSON.stringify(original));
            }
            return events;
        }
        // Case created
        if (!original) {
            events.push({ type: Customer.EVENT_CREATED, customer: this });
        }
        events.push({
            type: Customer.EVENT_UPDATED,
            customer: this,
            changes: diff_1.objectDiff(original, this),
        });
        this.bs_meta = bs_meta;
        return events;
    }
}
Customer.EVENT_CREATED = "CUSTOMER_CREATED";
Customer.EVENT_UPDATED = "CUSTOMER_UPDATED";
exports.Customer = Customer;

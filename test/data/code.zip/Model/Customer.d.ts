import { CanonicalCustomer } from "@nbeyer/bs-customer-db-model";
import { ICustomerUpdatedMessage } from "../Messages/Output/ICustomerUpdatedMessage";
export interface ICustomerIdentifier {
    email_hash?: string;
    id_md5?: string;
}
export declare class Customer extends CanonicalCustomer implements ICustomerIdentifier {
    static readonly EVENT_CREATED = "CUSTOMER_CREATED";
    static readonly EVENT_UPDATED = "CUSTOMER_UPDATED";
    static updateMeta(customerId: ICustomerIdentifier, query: any, upsert?: boolean): Promise<ICustomerUpdatedMessage>;
    /**
     * @returns {Promise<CanonicalOrder>}: The event that took place on this change.
     */
    updateDb(): Promise<any[]>;
}

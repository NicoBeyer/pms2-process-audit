import { CanonicalOrder, OrderIdentifier } from "@nbeyer/bs-customer-db-model";
import { OrderEventMessage } from "../Messages/Output/ICustomerDbMessage";
import { IOrderUpdatedMessage } from "../Messages/Output/IOrderUpdatedMessage";
export declare class Order extends CanonicalOrder {
    static updateMeta(orderId: OrderIdentifier, query: any, upsert?: boolean): Promise<IOrderUpdatedMessage>;
    /**
     * @returns {Promise<CanonicalOrder>}: The event that took place on this change.
     */
    updateDb(): Promise<OrderEventMessage[]>;
}

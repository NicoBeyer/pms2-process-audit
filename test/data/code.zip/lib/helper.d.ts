export declare function getElementAtPath(path: string | string[], obj: any): any;
export declare function leftDeepEqual(a: any, b: any): boolean;

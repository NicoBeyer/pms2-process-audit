export declare function objectDiff(a: any, b: any): object;

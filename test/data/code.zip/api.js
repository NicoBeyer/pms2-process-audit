"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const src_1 = require("@nbeyer/bs-customer-db-model/lib/src");
const Order_1 = require("./Model/Order");
class Api {
    async call(event) {
        console.log(event);
        let res = {};
        switch (event.object) {
            case "orders":
                res = await this.getOrders(event);
                break;
            case "revenue":
                res = await this.getRevenue(event);
                break;
            case "leakingbucket":
                res = await this.getLeakingBucket(event);
                break;
            default:
                throw new Error("Object unknown.");
                break;
        }
        return res;
    }
    /**
     * https://api.beyer-soehne.de/customerdb/orders?start={date.add(-62).format()}&fields=id,total_price,created_at,cancelled_at,line_items.variant_id,line_items.product_id,line_items.quantity,line_items.title,line_items.variant_title,line_items.created_at,line_items.order_id,customer.id,customer.orders_count,tags,financial_status
     *
     * @param event
     */
    async getOrders(event) {
        const query = {
            $and: [
                { created_at: {
                        $gte: (event.start ? new Date(event.start) : new Date(Date.now() - 24 * 60 * 60 * 1000))
                    },
                },
                { created_at: {
                        $lte: (event.end ? new Date(event.end) : new Date())
                    },
                },
            ],
        };
        if (process.env.DEBUG) {
            console.log(query);
        }
        let projection;
        if (event.fields) {
            const fields = event.fields.split(",");
            projection = {};
            for (const field of fields) {
                projection[field] = 1;
            }
        }
        const res = await src_1.DB.collection(Order_1.Order.getCollectionName()).find(query, { projection }).toArray();
        for (const order of res) {
            delete order._id;
            delete order.semaphore;
            delete order.private_data;
            if (order.customer) {
                delete order.customer.private_data;
                delete order.semaphore;
            }
            if (order.line_items) {
                for (const item of order.line_items) {
                    const i = item;
                    i.order_id = order.id;
                    i.created_at = order.created_at;
                }
                if (process.env.DEBUG) {
                    console.log("Updated line_items: " + JSON.stringify(order));
                }
            }
        }
        const response = {
            orders: res,
            timestamp: new Date(),
        };
        if (process.env.DEBUG) {
            console.log("Returning response with " + JSON.stringify(response).length + " bytes.");
            console.log("Orders: " + response.orders.length);
            console.log("Example Order: " + response.orders[0]);
        }
        return response;
    }
    async getRevenue(event) {
        const pipeline = [
            { $match: {
                    $and: [
                        { created_at: {
                                $gte: (event.start ? new Date(event.start) : new Date(Date.now() - 24 * 60 * 60 * 1000 * 395))
                            },
                        },
                        { created_at: {
                                $lte: (event.end ? new Date(event.end) : new Date())
                            },
                        },
                        { cancelled_at: null },
                        { refunds: { $size: 0 } },
                    ],
                } },
            { $group: {
                    _id: { month: { $month: "$created_at" }, year: { $year: "$created_at" } },
                    count: { $sum: 1 },
                    revenue: { $sum: "$total_price" },
                } },
            { $sort: { "_id.year": 1, "_id.month": 1 } },
        ];
        if (process.env.DEBUG) {
            console.log(pipeline);
        }
        const res = await src_1.DB.collection(Order_1.Order.getCollectionName()).aggregate(pipeline).toArray();
        if (process.env.DEBUG) {
            console.log("getRevenue returns " + JSON.stringify(res));
        }
        return res;
    }
    async getLeakingBucket(event) {
        const maxCount = Number(event.max_count) || 6;
        const pipeline = [
            { $match: {
                    cancelled: null,
                    refunds: { $size: 0 },
                } },
            { $group: {
                    _id: "$customer.id",
                    orderCount: { $sum: 1 },
                    lastOrderDate: { $max: "$created_at" },
                } },
            { $match: {
                    lastOrderDate: { $gte: new Date(new Date(Date.now() - 31536000000)) },
                } },
            { $group: {
                    _id: {
                        count: { $cond: [{ $gte: ["$orderCount", maxCount] }, maxCount, "$orderCount"] },
                        status: { $cond: [{ $gte: ["$lastOrderDate", new Date(Date.now() - 15768000000)] }, "active", "inactive"] },
                    },
                    count: { $sum: 1 },
                } },
        ];
        const res = await src_1.DB.collection(Order_1.Order.getCollectionName()).aggregate(pipeline).toArray();
        const ret = new Array(maxCount);
        for (const data of res) {
            const i = data._id.count - 1;
            if (!ret[i]) {
                ret[i] = {};
            }
            ret[i].count = data._id.count;
            if (data._id.status === "active") {
                ret[i].activeCount = data.count;
            }
            else {
                ret[i].inactiveCount = data.count;
            }
        }
        if (process.env.DEBUG) {
            console.log("getLeakingBucket returns " + JSON.stringify(ret));
        }
        return ret;
    }
}
exports.Api = Api;
